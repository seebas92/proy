document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;

  var users = {
    "sebasjejfvs@gmail.com": "0702Sebastian200427",
    "estebanjsjfvs@gmail.com": "0627Esteban201402",
    "caliteamo1912@gmail.com": "1912Depcali1992",
  };

  // Validación de los requisitos de la contraseña
  var uppercaseRegex = /[A-Z]/;
  var lowercaseRegex = /[a-z]/;
  var numberRegex = /[0-9]/;

  var validUppercase = uppercaseRegex.test(password);
  var validLowercase = lowercaseRegex.test(password);
  var validNumber = numberRegex.test(password);

  if (
    users.hasOwnProperty(username) &&
    users[username] === password &&
    validUppercase &&
    validLowercase &&
    validNumber
  ) {
    window.location.href = "veterinaria.html"; // Redirige a la página veterinaria.html
  } else {
    document.getElementById("loginMessage").innerText =
      "Usuario o contraseña incorrectos";
  }

  // Actualización de clases para los requisitos de contraseña
  document
    .getElementById("uppercaseLetter")
    .classList.toggle("valid", validUppercase);
  document
    .getElementById("lowercaseLetter")
    .classList.toggle("valid", validLowercase);
  document.getElementById("number").classList.toggle("valid", validNumber);
});

document.getElementById("password").addEventListener("input", function () {
  var password = this.value;

  var uppercaseRegex = /[A-Z]/;
  var lowercaseRegex = /[a-z]/;
  var numberRegex = /[0-9]/;

  var validUppercase = uppercaseRegex.test(password);
  var validLowercase = lowercaseRegex.test(password);
  var validNumber = numberRegex.test(password);

  // Actualización de clases para los requisitos de contraseña
  document
    .getElementById("uppercaseLetter")
    .classList.toggle("valid", validUppercase);
  document
    .getElementById("lowercaseLetter")
    .classList.toggle("valid", validLowercase);
  document.getElementById("number").classList.toggle("valid", validNumber);
});
