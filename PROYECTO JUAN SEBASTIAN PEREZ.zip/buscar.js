var productos = [
  "Camisa del equipo más grande de Colombia para perro",
  "Shampoo para perros con Insecticida",
  "Jabón para perros con Insecticida",
  "Pez Juguete para Gato",
  "Bloque de calcio para pájaros",
  "Hierba para gatos",
  "Baño para perros",
  "Moño para gato",
  "Tetero para cachorros",
  // Otros productos...
];

var paginas = {
  "Camisa del equipo más grande de Colombia para perro":
    "detalles.producto10.html",
  "Shampoo para perros con Insecticida": "detalles.producto1.html",
  "Jabón para perros con Insecticida": "detalles.producto2.html",
  "Pez Juguete para Gato": "detalles.producto3.html",
  "Bloque de calcio para pájaros": "detalles.producto11.html",
  "Hierba para gatos": "detalles.producto12.html",
  "Baño para perros": "detalles.producto21.html",
  "Moño para gato": "detalles.producto20.html",
  "Tetero para cachorros": "detalles.producto19.html",
  // Otros productos...
};
var categorias = [
  "Inicio",
  "Aseo y Cuidado",
  "Accesorios",
  "Juguetería",
  "Servicio",
  // Otras categorías...
];

// Resto del código...

function buscarCoincidencias() {
  var input = document.getElementById("searchInput").value.toLowerCase();
  var sugerenciasDiv = document.getElementById("sugerencias");
  sugerenciasDiv.innerHTML = "";

  if (input.length === 0) {
    sugerenciasDiv.style.display = "none";
    return;
  }

  var coincidencias = productos.filter(function (producto) {
    return producto.toLowerCase().includes(input);
  });

  sugerenciasDiv.style.display = "block";

  coincidencias.forEach(function (coincidencia) {
    var div = document.createElement("div");
    div.textContent = coincidencia;
    div.classList.add("sugerencia"); // Agregar clase sugerencia
    sugerenciasDiv.appendChild(div);
  });
}

function completarInput(event) {
  var clickedText = event.target.textContent;
  document.getElementById("searchInput").value = clickedText;
  document.getElementById("sugerencias").style.display = "none";

  if (paginas.hasOwnProperty(clickedText)) {
    window.location.href = paginas[clickedText];
  }
}
document.getElementById("categoryFilter").onchange = function () {
  var selectedValue = this.value;
  if (selectedValue === "Aseo y Cuidado") {
    window.location.href = "aseoycuidado.html";
  }
  // Agrega más condiciones para otras categorías si es necesario
};
